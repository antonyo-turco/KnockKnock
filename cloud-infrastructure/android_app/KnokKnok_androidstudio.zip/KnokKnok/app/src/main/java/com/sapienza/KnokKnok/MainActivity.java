package com.sapienza.KnokKnok;

import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "KnockKnock";
    private static final int SETTINGS_REQUEST_CODE = 100;

    private SwipeRefreshLayout swipeRefresh;
    private View alarmCardInner;
    private ImageView alarmIcon;
    private TextView alarmStatusText;
    private MaterialSwitch alarmSwitch;
    private TextView sensorCount;
    private RecyclerView sensorRecyclerView;
    private TextView emptyView;

    private LinearLayout logHeader;
    private ImageView logExpandIcon;
    private LinearLayout logContainer;
    private RecyclerView logRecyclerView;
    private TextView emptyLogView;

    private List<Device> deviceList;
    private SensorAdapter sensorAdapter;
    
    private List<LogEntry> logList;
    private LogAdapter logAdapter;

    private android.content.BroadcastReceiver sseReceiver;
    private boolean isAlarmArmed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(R.string.app_name);
        }

        // Initialize notification channel
        NotificationHelper.createNotificationChannel(this);

        // Request notification permission for Android 13+
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        // Initialize views
        swipeRefresh = findViewById(R.id.swipeRefresh);
        alarmCardInner = findViewById(R.id.alarmCardInner);
        alarmIcon = findViewById(R.id.alarmIcon);
        alarmStatusText = findViewById(R.id.alarmStatusText);
        alarmSwitch = findViewById(R.id.alarmSwitch);
        sensorCount = findViewById(R.id.sensorCount);
        sensorRecyclerView = findViewById(R.id.sensorRecyclerView);
        emptyView = findViewById(R.id.emptyView);

        logHeader = findViewById(R.id.logHeader);
        logExpandIcon = findViewById(R.id.logExpandIcon);
        logContainer = findViewById(R.id.logContainer);
        logRecyclerView = findViewById(R.id.logRecyclerView);
        emptyLogView = findViewById(R.id.emptyLogView);

        FloatingActionButton fabAddSensor = findViewById(R.id.fabAddSensor);

        // Setup RecyclerViews
        deviceList = new ArrayList<>();
        sensorRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        sensorAdapter = new SensorAdapter(this, deviceList);
        sensorRecyclerView.setAdapter(sensorAdapter);

        logList = new ArrayList<>();
        logRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        logAdapter = new LogAdapter(logList);
        logRecyclerView.setAdapter(logAdapter);

        // Logs empty state check
        updateLogsVisibility();

        // Expandable Log Section
        logHeader.setOnClickListener(v -> {
            if (logContainer.getVisibility() == View.VISIBLE) {
                logContainer.setVisibility(View.GONE);
                logExpandIcon.setImageResource(R.drawable.ic_expand_more);
            } else {
                logContainer.setVisibility(View.VISIBLE);
                logExpandIcon.setImageResource(R.drawable.ic_expand_less);
            }
        });

        // Swipe Refresh
        swipeRefresh.setColorSchemeColors(ContextCompat.getColor(this, R.color.primary));
        swipeRefresh.setOnRefreshListener(this::refreshData);

        // Alarm toggle switch
        alarmSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            setAlarmState(isChecked);
        });

        // FAB add sensor
        fabAddSensor.setOnClickListener(v -> showAddSensorDialog());

        // Setup the BroadcastReceiver for SSE Events from SseService
        setupSseReceiver();

        // Start SSE Service to maintain persistent background connection
        Intent serviceIntent = new Intent(this, SseService.class);
        startService(serviceIntent);

        // Schedule fallback periodic alarm polling using WorkManager
        androidx.work.PeriodicWorkRequest pollingRequest =
                new androidx.work.PeriodicWorkRequest.Builder(AlarmPollingWorker.class, 15, java.util.concurrent.TimeUnit.MINUTES)
                        .build();
        androidx.work.WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "AlarmPollingWork",
                androidx.work.ExistingPeriodicWorkPolicy.KEEP,
                pollingRequest
        );

        // Initial Data Fetch
        refreshData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Register BroadcastReceiver
        IntentFilter filter = new IntentFilter("com.sapienza.KnokKnok.SSE_EVENT");
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(sseReceiver, filter, android.content.Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(sseReceiver, filter);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Unregister BroadcastReceiver
        if (sseReceiver != null) {
            unregisterReceiver(sseReceiver);
        }
    }

    private void refreshData() {
        swipeRefresh.setRefreshing(true);
        loadAlarmState();
        loadDevices();
    }

    private void loadAlarmState() {
        ApiClient.getInstance(this).getAlarmState(new ApiClient.Callback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                isAlarmArmed = result;
                updateAlarmCardUI(isAlarmArmed);
                swipeRefresh.setRefreshing(false);
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Failed to load alarm state: " + error);
                swipeRefresh.setRefreshing(false);
            }
        });
    }

    private void loadDevices() {
        ApiClient.getInstance(this).getDevices(new ApiClient.Callback<List<Device>>() {
            @Override
            public void onSuccess(List<Device> result) {
                deviceList.clear();
                deviceList.addAll(result);
                sensorAdapter.notifyDataSetChanged();
                updateSensorViews();
                swipeRefresh.setRefreshing(false);
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Failed to load devices: " + error);
                swipeRefresh.setRefreshing(false);
            }
        });
    }

    private void setAlarmState(boolean enabled) {
        ApiClient.Callback<Boolean> callback = new ApiClient.Callback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                isAlarmArmed = enabled;
                updateAlarmCardUI(isAlarmArmed);
                addLogEntry(new LogEntry("ACK", "Alarm system successfully " + (enabled ? "Armed" : "Disarmed")));
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Failed to update alarm state: " + error);
                Toast.makeText(MainActivity.this, R.string.connection_error, Toast.LENGTH_SHORT).show();
                // Revert switch position
                alarmSwitch.setOnCheckedChangeListener(null);
                alarmSwitch.setChecked(!enabled);
                alarmSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> setAlarmState(isChecked));
            }
        };

        if (enabled) {
            ApiClient.getInstance(this).enableAlarm(callback);
        } else {
            ApiClient.getInstance(this).disableAlarm(callback);
        }
    }

    private void updateAlarmCardUI(boolean enabled) {
        alarmSwitch.setOnCheckedChangeListener(null);
        alarmSwitch.setChecked(enabled);
        alarmSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> setAlarmState(isChecked));

        if (enabled) {
            alarmCardInner.setBackgroundResource(R.drawable.bg_alarm_card_enabled);
            alarmStatusText.setText(R.string.alarm_armed);
            alarmIcon.setImageResource(R.drawable.ic_shield);
            alarmIcon.setImageTintList(ContextCompat.getColorStateList(this, R.color.alarmEnabled));
        } else {
            alarmCardInner.setBackgroundResource(R.drawable.bg_alarm_card_disabled);
            alarmStatusText.setText(R.string.alarm_disarmed);
            alarmIcon.setImageResource(R.drawable.ic_shield);
            alarmIcon.setImageTintList(ContextCompat.getColorStateList(this, R.color.alarmDisabled));
        }
    }

    private void updateSensorViews() {
        sensorCount.setText(deviceList.size() + (deviceList.size() == 1 ? " device" : " devices"));
        if (deviceList.isEmpty()) {
            sensorRecyclerView.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
        } else {
            sensorRecyclerView.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.GONE);
        }
    }

    private void addLogEntry(LogEntry entry) {
        logList.add(0, entry); // Add to top
        logAdapter.notifyItemInserted(0);
        logRecyclerView.scrollToPosition(0);
        updateLogsVisibility();
    }

    private void updateLogsVisibility() {
        if (logList.isEmpty()) {
            emptyLogView.setVisibility(View.VISIBLE);
            logRecyclerView.setVisibility(View.GONE);
        } else {
            emptyLogView.setVisibility(View.GONE);
            logRecyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void showAddSensorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.add_sensor_title);

        View view = LayoutInflater.from(this).inflate(R.layout.dialog_add_sensor, null);
        builder.setView(view);

        TextInputEditText inputMac = view.findViewById(R.id.inputMac);
        TextInputEditText inputName = view.findViewById(R.id.inputName);

        builder.setPositiveButton(R.string.add, null);
        builder.setNegativeButton(R.string.cancel, null);

        AlertDialog dialog = builder.create();
        dialog.show();

        // Override positive button click to perform validation without closing dialog automatically
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String mac = inputMac.getText() != null ? inputMac.getText().toString().trim().toUpperCase() : "";
            String name = inputName.getText() != null ? inputName.getText().toString().trim() : "";

            if (mac.isEmpty()) {
                inputMac.setError(getString(R.string.mac_required));
                return;
            }

            // Standard MAC validation: XX:XX:XX:XX:XX:XX or XX-XX-XX-XX-XX-XX
            String macRegex = "^([0-9A-FA-F]{2}[:-]){5}([0-9A-FA-F]{2})$";
            if (!mac.matches(macRegex)) {
                inputMac.setError(getString(R.string.invalid_mac));
                return;
            }

            dialog.dismiss();
            addSensor(mac, name);
        });
    }

    private void addSensor(String mac, String name) {
        ApiClient.getInstance(this).addDevice(mac, name, new ApiClient.Callback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                Toast.makeText(MainActivity.this, "Sensor registration published to hub", Toast.LENGTH_SHORT).show();
                refreshData();
            }

            @Override
            public void onError(String error) {
                Log.e(TAG, "Failed to add sensor: " + error);
                Toast.makeText(MainActivity.this, R.string.connection_error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupSseReceiver() {
        sseReceiver = new android.content.BroadcastReceiver() {
            @Override
            public void onReceive(android.content.Context context, Intent intent) {
                String type = intent.getStringExtra("type");
                String payloadStr = intent.getStringExtra("payload");
                if (type == null) return;

                try {
                    JSONObject payload = payloadStr != null ? new JSONObject(payloadStr) : new JSONObject();
                    handleSseEvent(type, payload);
                } catch (Exception e) {
                    Log.e(TAG, "Error handling broadcasted SSE event", e);
                }
            }
        };
    }

    private void handleSseEvent(String type, JSONObject payload) {
        Log.d(TAG, "Received broadcast event: " + type + ", data: " + payload.toString());

        switch (type.toUpperCase()) {
            case "ALARM":
                String sensorMac = payload.optString("mac_address", payload.optString("mac", "Unknown"));
                addLogEntry(new LogEntry("ALARM", "Vibration Alarm triggered on sensor " + sensorMac));
                break;
            case "ALARM_ACK":
                boolean enabled = payload.optBoolean("alarm_enabled", false);
                isAlarmArmed = enabled;
                updateAlarmCardUI(isAlarmArmed);
                addLogEntry(new LogEntry("ACK", "Alarm state synchronized to " + (enabled ? "Armed" : "Disarmed")));
                break;
            case "DEVICE_LIST_RESPONSE":
                loadDevices();
                addLogEntry(new LogEntry("DEVICE", "Hub device list synchronized"));
                break;
            case "DEVICE_ACK":
                String action = payload.optString("action", "unknown");
                boolean success = payload.optBoolean("success", false);
                String mac = payload.optString("mac_address", payload.optString("mac", ""));
                addLogEntry(new LogEntry("ACK", "Action " + action + " for " + mac + " returned success=" + success));
                loadDevices();
                break;
            case "TRAINING_ACK":
                String trMac = payload.optString("mac_address", payload.optString("mac", ""));
                boolean queued = payload.optBoolean("queued", false);
                addLogEntry(new LogEntry("ACK", "Training started for " + trMac + ", queued=" + queued));
                break;
            case "CONNECTED":
                addLogEntry(new LogEntry("INFO", "Real-time updates channel connected"));
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivityForResult(intent, SETTINGS_REQUEST_CODE);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            refreshData();
        }
    }
}