package com.sapienza.KnokKnok;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.slider.Slider;

public class SensorSettingsActivity extends AppCompatActivity {
    private static final String TAG = "KnockKnock";

    private String macAddress;
    private String deviceName;
    private String status;

    private TextView sensorNameTitle;
    private TextView sensorMacSubtitle;
    private View sensorStatusDot;
    private com.google.android.material.slider.Slider trainingDurationSlider;
    private android.widget.EditText trainingDurationValue;
    private Button btnStartTraining;
    private Button btnDeleteSensor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_settings);

        // Get intent extras
        macAddress = getIntent().getStringExtra("mac_address");
        deviceName = getIntent().getStringExtra("device_name");
        status = getIntent().getStringExtra("status");

        // Setup toolbar
        Toolbar toolbar = findViewById(R.id.settingsToolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(deviceName != null && !deviceName.isEmpty() ? deviceName : macAddress);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // Find views
        sensorNameTitle = findViewById(R.id.sensorNameTitle);
        sensorMacSubtitle = findViewById(R.id.sensorMacSubtitle);
        sensorStatusDot = findViewById(R.id.sensorStatusDot);
        trainingDurationSlider = findViewById(R.id.trainingDurationSlider);
        trainingDurationValue = findViewById(R.id.trainingDurationValue);
        btnStartTraining = findViewById(R.id.btnStartTraining);
        btnDeleteSensor = findViewById(R.id.btnDeleteSensor);

        // Display sensor info
        sensorNameTitle.setText(deviceName != null && !deviceName.isEmpty() ? deviceName : macAddress);
        sensorMacSubtitle.setText(macAddress);
        updateStatusDot();

        // Training slider
        trainingDurationSlider.addOnChangeListener((slider, value, fromUser) -> {
            if (fromUser) {
                trainingDurationValue.setText(String.valueOf((int) value));
            }
        });
        // Set initial value text
        trainingDurationValue.setText(String.valueOf((int) trainingDurationSlider.getValue()));

        // Manual training duration text edit synchronization
        trainingDurationValue.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(android.text.Editable s) {
                try {
                    int val = Integer.parseInt(s.toString());
                    if (val >= 10 && val <= 300) {
                        if (trainingDurationSlider.getValue() != val) {
                            trainingDurationSlider.setValue(val);
                        }
                    }
                } catch (NumberFormatException e) {
                    // Ignore empty or invalid numerical inputs
                }
            }
        });

        // Enlarge text size when focused for premium interactive visual feedback
        trainingDurationValue.setOnFocusChangeListener((v, hasFocus) -> {
            if (hasFocus) {
                trainingDurationValue.setTextSize(24);
            } else {
                trainingDurationValue.setTextSize(16);
            }
        });

        // Start training button
        btnStartTraining.setOnClickListener(v -> startTraining());

        // Delete button
        btnDeleteSensor.setOnClickListener(v -> showDeleteConfirmation());
    }

    private void updateStatusDot() {
        if (status == null) status = "unknown";
        switch (status.toLowerCase()) {
            case "online":
                sensorStatusDot.setBackgroundResource(R.drawable.bg_status_online);
                break;
            case "offline":
                sensorStatusDot.setBackgroundResource(R.drawable.bg_status_offline);
                break;
            default:
                sensorStatusDot.setBackgroundResource(R.drawable.bg_status_unknown);
                break;
        }
    }

    private void startTraining() {
        int durationSeconds;
        try {
            String inputText = trainingDurationValue.getText().toString().trim();
            if (inputText.isEmpty()) {
                throw new NumberFormatException("Empty input");
            }
            // Parse as long first to avoid instant standard integer overflow
            long parsedSeconds = Long.parseLong(inputText);
            if (parsedSeconds <= 0) {
                throw new NumberFormatException("Negative or zero duration");
            }
            // Cap at 1,000,000 seconds (~11.5 days) to protect both memory and hub API integrity
            if (parsedSeconds > 1000000) {
                parsedSeconds = 1000000;
                trainingDurationValue.setText(String.valueOf(parsedSeconds));
                Toast.makeText(this, "Capped training duration at maximum 1,000,000 seconds", Toast.LENGTH_SHORT).show();
            }
            durationSeconds = (int) parsedSeconds;
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid training duration (seconds)", Toast.LENGTH_SHORT).show();
            return;
        }
        int durationMs = durationSeconds * 1000;

        btnStartTraining.setEnabled(false);
        ApiClient.getInstance(this).startTraining(macAddress, durationMs, new ApiClient.Callback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                btnStartTraining.setEnabled(true);
                Toast.makeText(SensorSettingsActivity.this,
                        getString(R.string.training_started, durationSeconds),
                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(String error) {
                btnStartTraining.setEnabled(true);
                Toast.makeText(SensorSettingsActivity.this,
                        getString(R.string.connection_error),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showDeleteConfirmation() {
        String displayName = (deviceName != null && !deviceName.isEmpty()) ? deviceName : macAddress;
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(getString(R.string.delete_confirm_message, displayName))
                .setPositiveButton(R.string.delete, (dialog, which) -> deleteSensor())
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void deleteSensor() {
        btnDeleteSensor.setEnabled(false);
        ApiClient.getInstance(this).removeDevice(macAddress, new ApiClient.Callback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                Toast.makeText(SensorSettingsActivity.this,
                        getString(R.string.sensor_deleted),
                        Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            }

            @Override
            public void onError(String error) {
                btnDeleteSensor.setEnabled(true);
                Toast.makeText(SensorSettingsActivity.this,
                        getString(R.string.connection_error),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
