package com.sapienza.KnokKnok;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.preference.PreferenceManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class AlarmPollingWorker extends Worker {
    private static final String TAG = "KnockKnock";

    public AlarmPollingWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        Log.d(TAG, "AlarmPollingWorker background check started.");
        Context context = getApplicationContext();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);

        String serverUrl = prefs.getString("server_url", context.getString(R.string.default_server_url));
        String lastCheck = prefs.getString("last_alarm_check", "");

        // Create new check timestamp in UTC
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        String newCheckTime = sdf.format(new Date());

        HttpURLConnection conn = null;
        try {
            // First check if alarm is enabled!
            URL stateUrl = new URL(serverUrl + "/api/alarm/state");
            conn = (HttpURLConnection) stateUrl.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            if (conn.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                JSONObject stateObj = new JSONObject(response.toString());
                boolean alarmEnabled = stateObj.getBoolean("alarm_enabled");
                if (!alarmEnabled) {
                    Log.d(TAG, "Alarm system is disarmed. Skipping alerts.");
                    return Result.success();
                }
            }
            conn.disconnect();

            // Fetch recent alarms since last check
            String path = "/api/alarms/recent";
            if (!lastCheck.isEmpty()) {
                path += "?since=" + URLEncoder.encode(lastCheck, "UTF-8");
            }
            URL url = new URL(serverUrl + path);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            if (conn.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                JSONObject obj = new JSONObject(response.toString());
                JSONArray alarms = obj.getJSONArray("alarms");

                if (alarms.length() > 0) {
                    Log.i(TAG, "Intrusion alarms found: " + alarms.length());
                    for (int i = 0; i < alarms.length(); i++) {
                        JSONObject alarm = alarms.getJSONObject(i);
                        String sensorMac = alarm.getString("mac_address");
                        NotificationHelper.showAlarmNotification(context, sensorMac);
                    }
                }

                // Save latest check time on success
                prefs.edit().putString("last_alarm_check", newCheckTime).apply();
                return Result.success();
            } else {
                Log.e(TAG, "Server returned response code: " + conn.getResponseCode());
                return Result.retry();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error polling background alarms", e);
            return Result.retry();
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }
}
