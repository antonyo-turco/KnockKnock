package com.sapienza.KnokKnok;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import org.json.JSONObject;

public class SseService extends Service {
    private static final String TAG = "KnockKnock";
    private SseClient sseClient;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "SseService started.");
        if (sseClient == null) {
            sseClient = new SseClient(this, new SseClient.SseListener() {
                @Override
                public void onEvent(String type, JSONObject payload) {
                    // Send broadcast intent to update MainActivity UI if open
                    Intent broadcastIntent = new Intent("com.sapienza.KnokKnok.SSE_EVENT");
                    broadcastIntent.putExtra("type", type);
                    broadcastIntent.putExtra("payload", payload.toString());
                    sendBroadcast(broadcastIntent);

                    // Background alarm notification processing
                    if ("ALARM".equalsIgnoreCase(type)) {
                        String sensorMac = payload.optString("mac_address", payload.optString("mac", "Unknown"));
                        
                        // Check if alarm system is armed
                        ApiClient.getInstance(SseService.this).getAlarmState(new ApiClient.Callback<Boolean>() {
                            @Override
                            public void onSuccess(Boolean result) {
                                if (result) {
                                    NotificationHelper.showAlarmNotification(SseService.this, sensorMac);
                                }
                            }

                            @Override
                            public void onError(String error) {
                                Log.e(TAG, "Failed to get alarm state in background: " + error);
                            }
                        });
                    }
                }

                @Override
                public void onConnected() {
                    Log.i(TAG, "SseService connected to SSE stream.");
                    Intent broadcastIntent = new Intent("com.sapienza.KnokKnok.SSE_EVENT");
                    broadcastIntent.putExtra("type", "CONNECTED");
                    sendBroadcast(broadcastIntent);
                }

                @Override
                public void onDisconnected() {
                    Log.w(TAG, "SseService disconnected from SSE stream.");
                }
            });
            sseClient.start();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (sseClient != null) {
            sseClient.stop();
        }
        Log.d(TAG, "SseService destroyed.");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
