package com.sapienza.KnokKnok;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.preference.PreferenceManager;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.google.android.material.slider.Slider;
import com.google.android.material.textfield.TextInputEditText;

import java.util.concurrent.TimeUnit;

public class SettingsActivity extends AppCompatActivity {
    private static final String TAG = "KnockKnock";
    private static final String WORK_NAME = "alarm_polling";

    private TextInputEditText inputServerUrl;
    private SwitchCompat switchCustomSound;
    private Slider pollingIntervalSlider;
    private TextView pollingIntervalValue;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Setup toolbar
        Toolbar toolbar = findViewById(R.id.settingsToolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Settings");
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        // Find views
        inputServerUrl = findViewById(R.id.inputServerUrl);
        switchCustomSound = findViewById(R.id.switchCustomSound);
        pollingIntervalSlider = findViewById(R.id.pollingIntervalSlider);
        pollingIntervalValue = findViewById(R.id.pollingIntervalValue);
        btnSave = findViewById(R.id.btnSave);

        // Load current settings
        loadSettings();

        // Slider change listener
        pollingIntervalSlider.addOnChangeListener((slider, value, fromUser) -> {
            int val = (int) value;
            pollingIntervalValue.setText(val == 1 ? "1 minute" : String.format("%d minutes", val));
        });

        // Save button
        btnSave.setOnClickListener(v -> saveSettings());
    }

    private void loadSettings() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);

        String serverUrl = prefs.getString("server_url", getString(R.string.default_server_url));
        inputServerUrl.setText(serverUrl);

        boolean customSound = prefs.getBoolean("custom_sound_enabled", false);
        switchCustomSound.setChecked(customSound);

        int pollingInterval = prefs.getInt("polling_interval", 15);
        pollingIntervalSlider.setValue(Math.max(1, Math.min(30, pollingInterval)));
        pollingIntervalValue.setText(pollingInterval == 1 ? "1 minute" : String.format("%d minutes", pollingInterval));
    }

    private void saveSettings() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = prefs.edit();

        String serverUrl = inputServerUrl.getText() != null ?
                inputServerUrl.getText().toString().trim() : getString(R.string.default_server_url);
        if (serverUrl.isEmpty()) {
            serverUrl = getString(R.string.default_server_url);
        }
        // Remove trailing slash
        if (serverUrl.endsWith("/")) {
            serverUrl = serverUrl.substring(0, serverUrl.length() - 1);
        }
        editor.putString("server_url", serverUrl);

        editor.putBoolean("custom_sound_enabled", switchCustomSound.isChecked());

        int pollingInterval = (int) pollingIntervalSlider.getValue();
        editor.putInt("polling_interval", pollingInterval);

        editor.apply();

        // Reschedule the polling worker
        reschedulePollingWorker(pollingInterval);

        // Recreate notification channel if custom sound changed
        NotificationHelper.createNotificationChannel(this);

        Toast.makeText(this, getString(R.string.settings_saved), Toast.LENGTH_SHORT).show();
        finish();
    }

    private void reschedulePollingWorker(int intervalMinutes) {
        int clampedInterval = Math.max(15, intervalMinutes);
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                AlarmPollingWorker.class,
                clampedInterval, TimeUnit.MINUTES
        ).build();

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
        );
    }
}
