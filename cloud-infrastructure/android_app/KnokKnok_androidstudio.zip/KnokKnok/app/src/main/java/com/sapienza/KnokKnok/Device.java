package com.sapienza.KnokKnok;

public class Device {
    private String macAddress;
    private String deviceName;
    private String status; // "online", "offline", "unknown"

    public Device(String macAddress, String deviceName, String status) {
        this.macAddress = macAddress;
        this.deviceName = deviceName;
        this.status = status;
    }

    public String getMacAddress() { return macAddress; }
    public void setMacAddress(String macAddress) { this.macAddress = macAddress; }
    public String getDeviceName() { return deviceName; }
    public void setDeviceName(String deviceName) { this.deviceName = deviceName; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getDisplayName() {
        return (deviceName != null && !deviceName.isEmpty()) ? deviceName : macAddress;
    }
}
