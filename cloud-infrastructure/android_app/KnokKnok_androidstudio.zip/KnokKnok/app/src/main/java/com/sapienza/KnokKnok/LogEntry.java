package com.sapienza.KnokKnok;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LogEntry {
    private final long timestamp;
    private final String type;
    private final String message;

    public LogEntry(String type, String message) {
        this.timestamp = System.currentTimeMillis();
        this.type = type;
        this.message = message;
    }

    public String getFormattedTime() {
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(timestamp));
    }

    public String getType() { return type; }
    public String getMessage() { return message; }
}
