package com.sapienza.KnokKnok;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SensorAdapter extends RecyclerView.Adapter<SensorAdapter.ViewHolder> {
    private final Activity activity;
    private final List<Device> devices;

    public SensorAdapter(Activity activity, List<Device> devices) {
        this.activity = activity;
        this.devices = devices;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_sensor, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Device device = devices.get(position);
        holder.sensorName.setText(device.getDisplayName());
        holder.sensorMac.setText(device.getMacAddress());
        
        String status = device.getStatus();
        if (status == null) status = "unknown";
        holder.sensorStatus.setText(status.substring(0, 1).toUpperCase() + status.substring(1).toLowerCase());

        switch (status.toLowerCase()) {
            case "online":
                holder.statusDot.setBackgroundResource(R.drawable.bg_status_online);
                break;
            case "offline":
                holder.statusDot.setBackgroundResource(R.drawable.bg_status_offline);
                break;
            default:
                holder.statusDot.setBackgroundResource(R.drawable.bg_status_unknown);
                break;
        }

        holder.btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(activity, SensorSettingsActivity.class);
            intent.putExtra("mac_address", device.getMacAddress());
            intent.putExtra("device_name", device.getDeviceName());
            intent.putExtra("status", device.getStatus());
            activity.startActivityForResult(intent, 100);
        });
    }

    @Override
    public int getItemCount() {
        return devices.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public View statusDot;
        public TextView sensorName;
        public TextView sensorMac;
        public TextView sensorStatus;
        public ImageButton btnSettings;

        public ViewHolder(View itemView) {
            super(itemView);
            statusDot = itemView.findViewById(R.id.statusDot);
            sensorName = itemView.findViewById(R.id.sensorName);
            sensorMac = itemView.findViewById(R.id.sensorMac);
            sensorStatus = itemView.findViewById(R.id.sensorStatus);
            btnSettings = itemView.findViewById(R.id.btnSettings);
        }
    }
}
