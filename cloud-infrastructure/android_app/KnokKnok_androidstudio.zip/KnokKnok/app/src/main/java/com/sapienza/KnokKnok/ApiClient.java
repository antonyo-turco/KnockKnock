package com.sapienza.KnokKnok;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import androidx.preference.PreferenceManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ApiClient {
    private static ApiClient instance;
    private final Context context;
    private final ExecutorService executor;
    private final Handler mainHandler;

    public interface Callback<T> {
        void onSuccess(T result);
        void onError(String error);
    }

    private ApiClient(Context context) {
        this.context = context.getApplicationContext();
        this.executor = Executors.newSingleThreadExecutor();
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    public static synchronized ApiClient getInstance(Context context) {
        if (instance == null) {
            instance = new ApiClient(context);
        }
        return instance;
    }

    private String getServerUrl() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getString("server_url", context.getString(R.string.default_server_url));
    }

    private interface RequestAction<T> {
        T execute(String baseUrl) throws Exception;
    }

    private <T> void performRequest(RequestAction<T> action, Callback<T> callback) {
        executor.execute(() -> {
            try {
                String baseUrl = getServerUrl();
                T result = action.execute(baseUrl);
                mainHandler.post(() -> callback.onSuccess(result));
            } catch (Exception e) {
                e.printStackTrace();
                mainHandler.post(() -> callback.onError(e.getMessage()));
            }
        });
    }

    public void getDevices(Callback<List<Device>> callback) {
        performRequest(baseUrl -> {
            URL url = new URL(baseUrl + "/api/devices");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            if (conn.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                JSONObject obj = new JSONObject(response.toString());
                JSONArray arr = obj.getJSONArray("devices");
                List<Device> devices = new ArrayList<>();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject devObj = arr.getJSONObject(i);
                    devices.add(new Device(
                            devObj.getString("mac_address"),
                            devObj.optString("device_name", ""),
                            devObj.optString("status", "unknown")
                    ));
                }
                return devices;
            } else {
                throw new Exception("HTTP error code: " + conn.getResponseCode());
            }
        }, callback);
    }

    public void addDevice(String mac, String name, Callback<Boolean> callback) {
        performRequest(baseUrl -> {
            URL url = new URL(baseUrl + "/api/devices");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            JSONObject body = new JSONObject();
            body.put("mac_address", mac);
            body.put("device_name", name);

            OutputStream os = conn.getOutputStream();
            os.write(body.toString().getBytes());
            os.flush();
            os.close();

            if (conn.getResponseCode() == 200 || conn.getResponseCode() == 201) {
                return true;
            } else {
                throw new Exception("HTTP error code: " + conn.getResponseCode());
            }
        }, callback);
    }

    public void removeDevice(String mac, Callback<Boolean> callback) {
        performRequest(baseUrl -> {
            String encodedMac = URLEncoder.encode(mac, "UTF-8");
            URL url = new URL(baseUrl + "/api/devices/" + encodedMac);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("DELETE");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            if (conn.getResponseCode() == 200) {
                return true;
            } else {
                throw new Exception("HTTP error code: " + conn.getResponseCode());
            }
        }, callback);
    }

    public void getAlarmState(Callback<Boolean> callback) {
        performRequest(baseUrl -> {
            URL url = new URL(baseUrl + "/api/alarm/state");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            if (conn.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                JSONObject obj = new JSONObject(response.toString());
                return obj.getBoolean("alarm_enabled");
            } else {
                throw new Exception("HTTP error code: " + conn.getResponseCode());
            }
        }, callback);
    }

    public void enableAlarm(Callback<Boolean> callback) {
        performRequest(baseUrl -> {
            URL url = new URL(baseUrl + "/api/alarm/enable");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            if (conn.getResponseCode() == 200) {
                return true;
            } else {
                throw new Exception("HTTP error code: " + conn.getResponseCode());
            }
        }, callback);
    }

    public void disableAlarm(Callback<Boolean> callback) {
        performRequest(baseUrl -> {
            URL url = new URL(baseUrl + "/api/alarm/disable");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            if (conn.getResponseCode() == 200) {
                return true;
            } else {
                throw new Exception("HTTP error code: " + conn.getResponseCode());
            }
        }, callback);
    }

    public void startTraining(String mac, int durationMs, Callback<Boolean> callback) {
        performRequest(baseUrl -> {
            URL url = new URL(baseUrl + "/api/training/start");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            JSONObject body = new JSONObject();
            body.put("mac_address", mac);
            body.put("duration_ms", durationMs);

            OutputStream os = conn.getOutputStream();
            os.write(body.toString().getBytes());
            os.flush();
            os.close();

            if (conn.getResponseCode() == 200) {
                return true;
            } else {
                throw new Exception("HTTP error code: " + conn.getResponseCode());
            }
        }, callback);
    }

    public void syncDevices(Callback<Boolean> callback) {
        performRequest(baseUrl -> {
            URL url = new URL(baseUrl + "/api/devices/sync");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            if (conn.getResponseCode() == 200) {
                return true;
            } else {
                throw new Exception("HTTP error code: " + conn.getResponseCode());
            }
        }, callback);
    }

    public void getRecentAlarms(String since, Callback<JSONArray> callback) {
        performRequest(baseUrl -> {
            String path = "/api/alarms/recent";
            if (since != null && !since.isEmpty()) {
                path += "?since=" + URLEncoder.encode(since, "UTF-8");
            }
            URL url = new URL(baseUrl + path);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            if (conn.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();

                JSONObject obj = new JSONObject(response.toString());
                return obj.getJSONArray("alarms");
            } else {
                throw new Exception("HTTP error code: " + conn.getResponseCode());
            }
        }, callback);
    }
}
