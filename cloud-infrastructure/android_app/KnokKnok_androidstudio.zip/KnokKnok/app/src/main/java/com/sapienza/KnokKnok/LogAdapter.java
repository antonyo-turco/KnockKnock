package com.sapienza.KnokKnok;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class LogAdapter extends RecyclerView.Adapter<LogAdapter.ViewHolder> {
    private final List<LogEntry> logs;

    public LogAdapter(List<LogEntry> logs) {
        this.logs = logs;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_log, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LogEntry entry = logs.get(position);
        holder.logTimestamp.setText(entry.getFormattedTime());
        holder.logType.setText(entry.getType().toUpperCase());
        holder.logMessage.setText(entry.getMessage());

        Context context = holder.itemView.getContext();
        int colorRes;
        switch (entry.getType().toUpperCase()) {
            case "ALARM":
                colorRes = R.color.logAlarm;
                break;
            case "ACK":
                colorRes = R.color.logAck;
                break;
            case "DEVICE":
                colorRes = R.color.logDevice;
                break;
            default:
                colorRes = R.color.logInfo;
                break;
        }
        
        int color = ContextCompat.getColor(context, colorRes);
        // Set type badge background tint
        if (holder.logType.getBackground() instanceof GradientDrawable) {
            GradientDrawable drawable = (GradientDrawable) holder.logType.getBackground();
            drawable.setColor(color);
        } else {
            holder.logType.getBackground().setTint(color);
        }
    }

    @Override
    public int getItemCount() {
        return logs.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView logTimestamp;
        public TextView logType;
        public TextView logMessage;

        public ViewHolder(View itemView) {
            super(itemView);
            logTimestamp = itemView.findViewById(R.id.logTimestamp);
            logType = itemView.findViewById(R.id.logType);
            logMessage = itemView.findViewById(R.id.logMessage);
        }
    }
}
