package com.sapienza.KnokKnok;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import androidx.preference.PreferenceManager;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SseClient {
    private static final String TAG = "KnockKnock";
    private final Context context;
    private final SseListener listener;
    private final ExecutorService executor;
    private final Handler mainHandler;
    private boolean isRunning = false;
    private HttpURLConnection conn;

    public interface SseListener {
        void onEvent(String type, JSONObject payload);
        void onConnected();
        void onDisconnected();
    }

    public SseClient(Context context, SseListener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        this.executor = Executors.newSingleThreadExecutor();
        this.mainHandler = new Handler(Looper.getMainLooper());
    }

    public synchronized void start() {
        if (isRunning) return;
        isRunning = true;
        executor.execute(this::streamEvents);
    }

    public synchronized void stop() {
        isRunning = false;
        if (conn != null) {
            new Thread(() -> {
                try {
                    conn.disconnect();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }

    private void streamEvents() {
        int backoffMs = 2000;
        while (isRunning) {
            try {
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
                String baseUrl = prefs.getString("server_url", context.getString(R.string.default_server_url));

                URL url = new URL(baseUrl + "/api/events");
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "text/event-stream");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(0); // Infinite read timeout for SSE streaming

                Log.d(TAG, "Connecting to SSE stream...");
                int responseCode = conn.getResponseCode();
                if (responseCode == 200) {
                    backoffMs = 2000; // Reset backoff on successful connection
                    mainHandler.post(listener::onConnected);

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String line;
                    while (isRunning && (line = reader.readLine()) != null) {
                        line = line.trim();
                        if (line.startsWith("data:")) {
                            String dataJson = line.substring(5).trim();
                            if (!dataJson.isEmpty()) {
                                try {
                                    JSONObject event = new JSONObject(dataJson);
                                    String type = event.optString("type", "UNKNOWN");
                                    
                                    // Payload could be nested under a payload key, or top-level. Support both!
                                    JSONObject payload = event.optJSONObject("payload");
                                    if (payload == null) {
                                        payload = event;
                                    }
                                    
                                    final String eventType = type;
                                    final JSONObject eventPayload = payload;
                                    mainHandler.post(() -> listener.onEvent(eventType, eventPayload));
                                } catch (Exception parseEx) {
                                    Log.e(TAG, "Error parsing SSE data: " + dataJson, parseEx);
                                }
                            }
                        }
                    }
                    reader.close();
                } else {
                    Log.w(TAG, "SSE connection failed with response code: " + responseCode);
                }
            } catch (Exception e) {
                if (isRunning) {
                    Log.e(TAG, "SSE stream connection error: " + e.getMessage());
                }
            } finally {
                if (conn != null) {
                    conn.disconnect();
                    conn = null;
                }
                mainHandler.post(listener::onDisconnected);
            }

            if (isRunning) {
                try {
                    Log.d(TAG, "Reconnecting in " + backoffMs + "ms...");
                    Thread.sleep(backoffMs);
                    backoffMs = Math.min(backoffMs * 2, 60000); // Exponential backoff capped at 60s
                } catch (InterruptedException ie) {
                    break;
                }
            }
        }
    }
}
